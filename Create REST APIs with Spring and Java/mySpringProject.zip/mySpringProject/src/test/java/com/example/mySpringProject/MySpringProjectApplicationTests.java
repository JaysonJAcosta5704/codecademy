package com.example.mySpringProject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MySpringProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
